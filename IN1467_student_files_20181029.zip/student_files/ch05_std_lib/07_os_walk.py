import os

for (dirname, subdirs, files) in os.walk('..'):
   for filename in files:
       if filename.endswith('.txt') :
           filepath = os.path.join(dirname, filename)
           print('{0:<20}{1:>8}   {2:40}'.format(filename, os.path.getsize(filepath), '(' + dirname + ')'))
