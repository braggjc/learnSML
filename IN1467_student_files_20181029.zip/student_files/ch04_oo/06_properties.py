from ch04_oo.modules.contacts3 import Contact

c = Contact()
c.name = 'Bob'
c.email = 'bob@yahoo.com'
print(c, c.email)