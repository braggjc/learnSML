"""

      task4_1.py    -   Classes

      This version of the baseball app creates a Player class
      and stores a list of Players objects.

      It assumes the student_files folder is on the PYTHONPATH

"""
import os

import ch04_oo.solutions.task4_1.support.stats as stats

working_dir = '../../../resources/baseball/'
master_filename = 'Master.csv'
salaries_filename = 'Salaries.csv'
results_filename = 'results.txt'

salfile_fullpath = os.path.join(working_dir, salaries_filename)
mastfile_fullpath = os.path.join(working_dir, master_filename)


input_year = stats.get_year()
top_sals = stats.retrieve_data(salfile_fullpath, mastfile_fullpath, input_year)
stats.print_report(results_filename, top_sals)
