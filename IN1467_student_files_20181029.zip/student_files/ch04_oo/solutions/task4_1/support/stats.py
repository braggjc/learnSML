import locale

locale.setlocale(locale.LC_ALL, '')


class Player:
    """
        Defines a Player and Player info (name, salary, year played).
    """
    def __init__(self, f_name, l_name, salary, year_played):
        self.first_name = f_name
        self.last_name = l_name
        self.salary = salary                                # this is invoking the setter property
        self.year_played = year_played

    @property
    def salary(self):
        return self._salary

    @salary.setter
    def salary(self, salary):
        self._salary = 0
        if salary > 0:
            self._salary = salary


def salary_sort(sal_record):
    salary = 0
    try:
        salary = int(sal_record[4])
    except ValueError:
        pass

    return salary


def get_year():
    return input('Search salaries for what year?--> ')


def retrieve_data(salaries_filepath, master_filepath, input_year=1985, num_records=10):
    salaries = []
    players = {}
    top_sals = []

    try:
        with open(salaries_filepath, encoding='utf8') as f_sal, \
             open(master_filepath, encoding='utf8') as f_mast:
            for line in f_sal:
                sal_record = line.strip().split(',')
                record_year = sal_record[0]
                if record_year == input_year:
                    salaries.append(sal_record)

            for line in f_mast:
                mast_record = line.strip().split(',')
                players[mast_record[0]] = mast_record

            salaries.sort(key=salary_sort, reverse=True)

            for top_sal in salaries[:num_records]:
                year = top_sal[0]
                salary = int(top_sal[4])
                playerid = top_sal[3]
                player_data = players.get(playerid)
                if player_data:
                    first_name = player_data[13]
                    last_name = player_data[14]
                    top_sals.append(Player(first_name, last_name, salary, year))
    except IOError as e:
        print('Error: {0}'.format(e))

    return top_sals


def print_report(results_filename, top_sals):
    try:
        with open(results_filename, 'w', encoding='utf8') as f_out:
            print('{0:<40} {1:<20} {2:<8}'.format('Name', 'Salary', 'Year'))
            print('{0:<40} {1:<20} {2:<8}'.format('Name', 'Salary', 'Year'), file=f_out)
            for player in top_sals:
                name = ' '.join([player.first_name, player.last_name])
                salary = locale.currency(int(player.salary), grouping=True)
                year = player.year_played
                print('{0:<40} {1:<20} {2:<8}'.format(name, salary, year))
                print('{0:<40} {1:<20} {2:<8}'.format(name, salary, year), file=f_out)
    except IOError as e:
        print(e)
