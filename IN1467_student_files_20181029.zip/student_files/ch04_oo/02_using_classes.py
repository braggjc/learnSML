class Contact:
    def __init__(self, name='', address=''):
        self.name = name
        self.address = address

    def display_columned(self, nw=20, aw=25):
        return '{0:<{nw}} {1:<{aw}} '.format(self.name, self.address, nw=nw, aw=aw)

    def __str__(self):
        return '{0} {1}'.format(self.name, self.address)


c = Contact('John Smith', '123 Main St.')

print(c.display_columned())
