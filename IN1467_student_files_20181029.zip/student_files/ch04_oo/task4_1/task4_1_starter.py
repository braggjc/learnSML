"""

      task4_1_starter.py    -   Classes

      This version of the baseball app starts from Task3_1 (solution).
      Task 4_1 creates a Player class and stores a list of Player
      objects.


      Step 1. Open support/stats.py.  Create a Player class there.


      Step 2. In the Player class, define a constructor (__init__)  that
              accepts a first name, last name, salary, and year


      Step 3. Create getters for the salary property.  Here's a sample
              for the first name property:

                    @property
                    def first_name(self):
                        return self._first_name


      Step 4. Create a setter for the salary


      Step 5. In the retrieve_data() function, replace the following line:

              top_sals.append([first_name, last_name, salary, year])

              with one that first instantiates a Player() instance and then
              adds the player instance to the top_sals list


      Step 6. Can you determine how the print_report() function needs to change?
"""
import os

import ch04_oo.task4_1.support.stats as stats

working_dir = '../../resources/baseball/'
master_filename = 'Master.csv'
salaries_filename = 'Salaries.csv'
results_filename = 'results.txt'

salfile_fullpath = os.path.join(working_dir, salaries_filename)
mastfile_fullpath = os.path.join(working_dir, master_filename)


input_year = stats.get_year()
top_sals = stats.retrieve_data(salfile_fullpath, mastfile_fullpath, input_year)
stats.print_report(results_filename, top_sals)
