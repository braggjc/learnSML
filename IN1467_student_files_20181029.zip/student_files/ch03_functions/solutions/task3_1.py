"""

      task3_1.py   -   Modules and Functions

      Modularizes task2_1 by creating functions within stats.py

"""
import os

import ch03_functions.solutions.support.stats as stats

working_dir = '../../resources/baseball/'
master_filename = 'Master.csv'
salaries_filename = 'Salaries.csv'
results_filename = 'results.txt'

salfile_fullpath = os.path.join(working_dir, salaries_filename)
mastfile_fullpath = os.path.join(working_dir, master_filename)


input_year = stats.get_year()
top_sals = stats.retrieve_data(salfile_fullpath, mastfile_fullpath, input_year)
stats.print_report(results_filename, top_sals)
