import locale

locale.setlocale(locale.LC_ALL, '')


def salary_sort(sal_record):
    salary = 0
    try:
        salary = int(sal_record[4])
    except ValueError:
        pass

    return salary


def get_year():
    return input('Search salaries for what year?--> ')


def retrieve_data(salaries_filepath, master_filepath, input_year=1985, num_records=10):
    salaries = []
    players = {}
    top_sals = []

    try:
        with open(salaries_filepath, encoding='utf8') as f_sal, \
             open(master_filepath, encoding='utf8') as f_mast:
            for line in f_sal:
                sal_record = line.strip().split(',')
                record_year = sal_record[0]
                if record_year == input_year:
                    salaries.append(sal_record)

            for line in f_mast:
                mast_record = line.strip().split(',')
                players[mast_record[0]] = mast_record

            salaries.sort(key=salary_sort, reverse=True)

            for top_sal in salaries[:num_records]:
                year = top_sal[0]
                salary = int(top_sal[4])
                playerid = top_sal[3]
                player_data = players.get(playerid)
                if player_data:
                    first_name = player_data[13]
                    last_name = player_data[14]
                    top_sals.append([first_name, last_name, salary, year])
    except IOError as e:
        print('Error: {0}'.format(e))

    return top_sals


def print_report(results_filename, top_sals):
    try:
        with open(results_filename, 'w', encoding='utf8') as f_out:
            print('{0:<40} {1:<20} {2:<8}'.format('Name', 'Salary', 'Year'))
            print('{0:<40} {1:<20} {2:<8}'.format('Name', 'Salary', 'Year'), file=f_out)
            for player_data in top_sals:
                name = ' '.join(player_data[0:2])
                salary = locale.currency(int(player_data[2]), grouping=True)
                year = player_data[3]
                print('{0:<40} {1:<20} {2:<8}'.format(name, salary, year))
                print('{0:<40} {1:<20} {2:<8}'.format(name, salary, year), file=f_out)
    except IOError as e:
        print(e)
