"""

      task3_1_starter.py   -   Modules and Functions

      This was the solution from task2_1.py.
      Work from this file or replace it with your own previous solutions.

      Your task: Create functions out of the solution below and move them into
                 the task3_1_support/stats.py file.  Then import that file
                 invoking those functions within your code here.


      Step 1. Either use this file or make a copy of your own task2_1_starter.py file.
              Create functions out of the different sections.  For example,
              you may wish to create a function for each of these:
              1) reading user input
              2) retrieving data
              3) printing the output


      Step 2. Move each function into the ch03_functions/task3_1_support/stats.py file.


      Step 3. Be sure to place the student_files folder on the PYTHONPATH unless using
              PyCharm, in which case student_files will already be on your sys.path


      Step 4. Properly import stats.py into this file.  Invoke the functions from that file.


      Step 5. Test your solution to ensure it works.

"""
import locale
import os


locale.setlocale(locale.LC_ALL, '')

working_dir = '../../resources/baseball/'
master_filename = 'Master.csv'
salaries_filename = 'Salaries.csv'
results_filename = 'results.txt'

num_records = 10
salaries = []
players = {}
top_sals = []


def salary_sort(sal_record):
    """Sorts the player-salary data by salary"""
    salary = 0
    try:
        salary = int(sal_record[4])
    except ValueError:
        pass

    return salary


input_year = input('Search salaries for what year?--> ')


try:
    with open(os.path.join(working_dir, salaries_filename)) as f_sal, \
         open(os.path.join(working_dir, master_filename)) as f_mast:
        for line in f_sal:
            sal_record = line.strip().split(',')
            record_year = sal_record[0]
            if record_year == input_year:
                salaries.append(sal_record)

        for line in f_mast:
            mast_record = line.strip().split(',')
            players[mast_record[0]] = mast_record

        salaries.sort(key=salary_sort, reverse=True)

        for top_sal in salaries[:num_records]:
            year = top_sal[0]
            playerid = top_sal[3]
            salary = top_sal[4]
            player_data = players.get(playerid)
            if player_data:
                first_name = player_data[13]
                last_name = player_data[14]
                top_sals.append([first_name, last_name, salary, year])
except IOError as e:
    print('Error: {0}'.format(e))


try:
    with open(results_filename, 'w', encoding='utf8') as f_out:
        f_out.write('Results\n')
        f_out.write('{0:<40} {1:<20} {2:<8}\n'.format('Name', 'Salary', 'Year'))
        for player_data in top_sals:
            name = ' '.join(player_data[0:2])
            salary = locale.currency(int(player_data[2]), grouping=True)
            year = player_data[3]
            f_out.write('{0:<40} {1:<20} {2:<8}\n'.format(name, salary, year))
except IOError as e:
    print(e)


# Testing the results
try:
    with open(results_filename) as f_test:                              # read the results back to verify them
        for line in f_test:
            print(line.rstrip())
except IOError as e:
    print(e)

