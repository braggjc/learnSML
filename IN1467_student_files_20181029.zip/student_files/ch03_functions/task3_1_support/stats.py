# To be used (imported by) task3_1_starter.py.

# Place functions from your task3_1_starter.py or
# your own previous solution into this module