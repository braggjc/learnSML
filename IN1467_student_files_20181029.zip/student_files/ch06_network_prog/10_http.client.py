import http.client
conn = http.client.HTTPSConnection(host='www.cisco.com')
conn.request(method='GET', url='/', body='', headers={'User-Agent': 'Not Mozilla'})
response = conn.getresponse()
print('Status: {0}\n{1}'.format(response.status, response.read().decode().strip()))
