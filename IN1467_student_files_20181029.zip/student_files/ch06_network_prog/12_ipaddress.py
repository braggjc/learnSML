import ipaddress

ip_addr1 = ipaddress.ip_address('192.168.0.1')
ip_addr2 = ipaddress.ip_address('192.168.1.1')
ip_network = ipaddress.ip_network('192.168.0.0/28')

print(ip_addr1 in ip_network)
print(ip_addr1 > ip_addr2)
print(list(ip_network))

for addr in ipaddress.ip_network('192.0.2.0/30'):
    print(addr)
