import requests

r = requests.get("http://www.yahoo.com")
print(r.url)
print(r.status_code)
print(r.headers)
print(r.request.headers)
print(r.text)
# print(r.cookies)
# for r in r.iter_lines():
#     pass
# print(r.history)
# print(r.content)
# print(r.json())


# r = requests.post("http://someURL", data = {'key': 'value'})
# r = requests.put("http://someURL", data = {'key': 'value'})
# r = requests.delete("http://someURL")
# r = requests.head("http://someURL")
# r = requests.options("http://someURL")

