from bs4 import BeautifulSoup     # pip install beautifulsoup4
import requests                   # pip install requests

req = requests.get('http://cisco.com')
html_text = req.text
html_headers = req.headers

soup = BeautifulSoup(html_text, 'html.parser')
print(soup.title)
print(soup.title.text)

print('-----')
print('h3\'s on the page:')
for elem in soup.find_all('h3'):
    print(elem.text)

print('-----')
headline = soup.select('h2.headline')[0]    # select() accepts CSS selectors
print(headline.text)

p = soup.select('p.description')[0]         # if there's a description subtitle this will display
print(p.text)
