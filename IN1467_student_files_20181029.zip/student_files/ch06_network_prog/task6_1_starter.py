"""
    task6_1_starter.py  -   Using JSON, Soup, and HTML Parsing

    This task asks you to retrieve the JSON data at the URL provided
    using the requests module.

    You should then parse the data using requests.get(url).json()

    Examine the resulting data structure.  Display the names of each fire.  These
    can be found within a dictionary nested within the overall dictionary.

    Extract the url of the first fire incident.

    Retrieve this page using requests again. This time parse it using BeautifulSoup.
    Display the third <p> tag from this page using find_all()




    Step 1. Be sure to  pip install beautifulsoup4 and pip install requests
            before proceeding.


    Step 2. Use the requests module (as discussed in the student materials) to make a
            request to http://inciweb.nwcg.gov/feeds/json/markers/

            This should return some JSON data.  Parse it to a dict type using .json().


    Step 3. You can test your results by just printing them temporarily.


    Step 4. Iterate over the 'markers' property of the JSON object.
            Hint: incidents['markers'] returns a list--see the slide in
                  your manual which displays the format of the data.

            Print the name of each fire.

            Test run it again.


    Step 5. Obtain the top fire (this will be the 0th one in the 'markers' list of fires.
            Obtain the url attribute associated with this fire.

            Be sure to append this url to the page_prefix variable.

            Retrieve the HTML for this page using requests.get(url).content.

            Parse the HTML using soup = BeautifulSoup(html_string, 'html.parser').

            Find all the '<p>' tags using the BeautifulSoup select method.  Select
            accepts CSS-type selectors.  The following selector should work
            (though note: HTML pages do change, as of this writing, the following selector
            worked):  '#incidentOverview p'

            Temporarily print the results of getting all of the <p> tags.  One of these
            results will contain the description.
            For example, if the description is the 0th
            <p> tag, you can display it individually by using:

                print(soup.select('#incidentOverview p')[0].text)

            Display the fire's description.
"""
from bs4 import BeautifulSoup
import requests

page_prefix = 'http://inciweb.nwcg.gov'
page = '/feeds/json/markers/'
fire_data = {}

