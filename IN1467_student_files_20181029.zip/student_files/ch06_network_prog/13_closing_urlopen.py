import contextlib

from urllib.request import urlopen
from urllib.error import  URLError
results = ''

try:
    with(contextlib.closing(urlopen('http://www.yahoo.com'))) as f_url:
        results = f_url.read().decode()
except (URLError, UnicodeDecodeError) as err:
    print('Error: {err}'.format(err=err))

print(results)
