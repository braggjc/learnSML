"""

      11_baseball_jinja2.py   -   Jinja2 Templating

      Reads data from multiple files.  Determines the top salaries for
      a specified year between 1985 and 2014.

      Renders output to an HTML page using Jinja2 templating

      Salaries.csv file format:  yearID,teamID,lgID,playerID,salary
      Master.csv   file format:  playerID,birthYear,birthMonth,birthDay,birthCountry,birthState,birthCity,deathYear,deathMonth,deathDay,deathCountry,deathState,deathCity,nameFirst,nameLast,nameGiven,weight,height,bats,throws,debut,finalGame,retroID,bbrefID

"""

import locale
import os.path
import webbrowser
from jinja2 import Environment, FileSystemLoader
from jinja2.exceptions import TemplateError, TemplateNotFound


def formatter(val, fmt=',.2f'):
    return '${0:{1}}'.format(float(val), fmt)

env = Environment(loader=FileSystemLoader('./templates'))
env.filters.update({'formatter': formatter})

locale.setlocale(locale.LC_ALL, '')

working_dir = '../resources/baseball/'
master_filename = 'Master.csv'
salaries_filename = 'Salaries.csv'
results_filename = 'baseball_stats_rendered.html'

num_records = 10
salaries = []
players = {}
top_sals = []


def salary_sort(sal_record):
    """Sorts the player-salary data by salary"""
    salary = 0
    try:
        salary = int(sal_record[4])
    except ValueError:
        pass

    return salary


input_year = input('Search salaries for what year?--> ')



try:
    with open(os.path.join(working_dir, salaries_filename)) as f_sal, \
         open(os.path.join(working_dir, master_filename)) as f_mast:
        for line in f_sal:
            sal_record = line.strip().split(',')
            record_year = sal_record[0]
            if record_year == input_year:
                salaries.append(sal_record)

        for line in f_mast:
            mast_record = line.strip().split(',')
            players[mast_record[0]] = mast_record

        salaries.sort(key=salary_sort, reverse=True)

        for top_sal in salaries[:num_records]:
            year = top_sal[0]
            playerid = top_sal[3]
            salary = top_sal[4]
            player_data = players.get(playerid)
            if player_data:
                first_name = player_data[13]
                last_name = player_data[14]
                top_sals.append([first_name, last_name, salary, year])
except IOError as e:
    print('Error: {0}'.format(e))


try:
    tmpl = env.get_template('baseball_stats.jinja')             # load the template
    results = tmpl.render(records=top_sals)                     # render data into template, returns a string

    with open(results_filename, 'w', encoding='utf8') as f:     # write results to a file
        f.write(results)

except (TemplateError, TemplateNotFound, IOError) as e:
    print('Error: {0}, {1}'.format(type(e), e))

webbrowser.open(results_filename)                               # display results in a browser
