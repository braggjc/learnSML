"""

      task2_1.py   -   Baseball player salaries

      Reads data from multiple files.  Determines the top salaries for
      a specified year between 1985 and 2015.

      Salaries.csv file format:  yearID,teamID,lgID,playerID,salary
      Master.csv   file format:  playerID,birthYear,birthMonth,birthDay,birthCountry,birthState,birthCity,deathYear,
                                 deathMonth,deathDay,deathCountry,deathState,deathCity,nameFirst,nameLast,nameGiven,
                                 weight,height,bats,throws,debut,finalGame,retroID,bbrefID

"""

import locale
import os


locale.setlocale(locale.LC_ALL, '')

working_dir = '../../resources/baseball/'
master_filename = 'Master.csv'
salaries_filename = 'Salaries.csv'
results_filename = 'results.txt'

num_records = 10
salaries = []
players = {}
top_sals = []


def salary_sort(sal_record):
    """Sorts the player-salary data by salary"""
    salary = 0
    try:
        salary = int(sal_record[4])
    except ValueError:
        pass

    return salary


input_year = input('Search salaries for what year?--> ')


try:
    with open(os.path.join(working_dir, salaries_filename)) as f_sal, \
         open(os.path.join(working_dir, master_filename)) as f_mast:
        for line in f_sal:
            sal_record = line.strip().split(',')
            record_year = sal_record[0]
            if record_year == input_year:
                salaries.append(sal_record)

        for line in f_mast:
            mast_record = line.strip().split(',')
            players[mast_record[0]] = mast_record

        salaries.sort(key=salary_sort, reverse=True)

        for top_sal in salaries[:num_records]:
            year = top_sal[0]
            playerid = top_sal[3]
            salary = top_sal[4]
            player_data = players.get(playerid)
            if player_data:
                first_name = player_data[13]
                last_name = player_data[14]
                top_sals.append([first_name, last_name, salary, year])
except IOError as e:
    print('Error: {0}'.format(e))


try:
    with open(results_filename, 'w', encoding='utf8') as f_out:
        f_out.write('Results\n')
        f_out.write('{0:<40} {1:<20} {2:<8}\n'.format('Name', 'Salary', 'Year'))
        for player_data in top_sals:
            name = ' '.join(player_data[0:2])
            salary = locale.currency(int(player_data[2]), grouping=True)
            year = player_data[3]
            f_out.write('{0:<40} {1:<20} {2:<8}\n'.format(name, salary, year))
except IOError as e:
    print(e)


# Testing the results
try:
    with open(results_filename) as f_test:                              # read the results back to verify them
        for line in f_test:
            print(line.rstrip())
except IOError as e:
    print(e)
