"""

       task1_3_starter.py   -   A simple grep utility


    Use the following command-line syntax run running this script:

        python task1_3_starter.py wordexpression directory


    Tips to help you out:
    1. Obtain the command-line arguments.  There are two: wordexpression and directory.
       This step has been taken care of for you in the starter code below.

       You should use os.listdir() to get a list of files from the specified directory.
       Iterate over the list of filenames and verify if they are all files.
       Hint: you can use os.path.isfile() to check for valid files.
       Note: another helpful tool is os.path.join(directory_name, filename).

       Use the append() method to add files to the provided file_list variable.


    2. Opening/reading/writing/closing files will be discussed further later,
       so for now, you have been shown how to read a line from a file:

            for line in open(filename, encoding='utf8'):
                # process line from file


        Overall your steps should be something like this:
            - Iterate over the file_list.
            - Open each file (from the list) one at a time
            - Read each line in, check for the presence of the wordexpression
                Hint: Use .find() for this
            - Output a result if there is a match

    Note: This exercise works only with text files.  Non-text files (binary
          files) will raise a UnicodeDecodeError.
"""

import sys
import os

args = sys.argv                                                 # get command-line args

if len(args) != 3:
    print('Insufficient arguments provided. Syntax:')
    print('python task1_3.py wordexpression directory')
    sys.exit(42)

# put your solution here
wordexpression = args[1]
directory = args[2]
file_list = []
