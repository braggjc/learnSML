"""

       task1_2_starter.py


 Additional Hints:
   1. Prompt for a URL input
        Example:
                    user_input_str = input('Enter a value: ')

   2. Check if URL begins with any of the prefixes by using .startswith()
      If it does, capture the remaining part of the URL using slicing
        Example:
                 value = 'hello world'
                 if value.startswith('hello')
                     remaining = value[len('hello'):]

  3. Repeat this task for the suffixes.  Use .find() for the
     suffixes.  find() returns a -1 for items not found in the string
     For example:
                 value = 'hello world'
                 position = value.find('world')
                 remaining = value[:position]
"""

prefixes = ['http://', 'https://']
suffixes = [':', '/', '?']

