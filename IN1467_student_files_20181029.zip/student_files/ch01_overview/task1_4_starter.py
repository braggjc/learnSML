"""

      Task1_4_starter.py   -   File size sorter utility

      This script will prompt for a path (and/or) pattern to search.
      It should display a list of files matching that path in order of largest
      to smallest


      Additional tips:

      1. Prompt for a path to search.  Example: ./*.py

      2. Perform a glob.glob(path) which returns a list of strings that match.
         Note: path MUST end with a Unix-style notation.

      3. Iterate over the results, check each result to see if it is a file.
         Hint: use os.path.isfile(filename)

      4. Create a list of files (by removing subdirectories)

      5. Sort the list according to file size.  Hint: use the list.sort() or sorted().
         Don't forget to sort from largest to smallest.

      6. Display the files.

"""
import glob
import os

