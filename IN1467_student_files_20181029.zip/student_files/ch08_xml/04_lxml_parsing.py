import sys

from collections import namedtuple
from lxml.etree import ElementTree
from lxml.etree import ParseError

Contact = namedtuple('ContactRecord', 'first last age email')

try:
    tree = ElementTree().parse('results.xml')
except ParseError as err:
    print('Parsing failed: {err}'.format(err=err))
    sys.exit(42)

contacts = []

for contact in tree.getiterator('contact'):
    try:
        first = contact.find('.//first').text
        last = contact.find('.//last').text
        age = contact.find('./name').get('age')
        email = contact.find('.//email').text
        contacts.append(Contact(first, last, age, email))
    except AttributeError as e:
        print('Element error: {err}'.format(err=e))

print(contacts)
