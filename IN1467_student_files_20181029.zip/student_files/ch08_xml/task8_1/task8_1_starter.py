"""

      task8_1_starter.py    -   XML

      This final version of the baseball app adds a create_xml()
      method to the stats.py module and outputs data into a file
      in prettified XML format.

    Step 1: Open the stats.py module in the support folder

    Step 2: Create a function in stats.py called create_xml()

    Step 3: Add appropriate imports for either cElementTree module or lxml parser.
            import xml.etree.cElementTree as etree
            from xml.etree.cElementTree import ElementTree
            from xml.etree.cElementTree import Element

            or

            import lxml.etree as etree
            from lxml.etree import ElementTree
            from lxml.etree import Element


    Step 4: Create the root element and ElementTree objects within the
            create_xml() function.  Iterate over the top sals creating
            appropriate xml elements.  This has been started for you below,
            you should complete the method...

                root = Element('players')
                tree = ElementTree(root)

                for record in top_sals:
                    player = Element('player')


            After building the XML using the ElementTree APIs,
            pretty print the results to a file.  You can do
            this using the code provided below:

            from xml.dom import minidom
            xml_str = etree.tostring(root)
            pretty_xml = minidom.parseString(xml_str).toprettyxml(indent='   ', encoding='utf8')
            xml_results = pretty_xml.decode()
            try:
                with open(filename, 'w', encoding='utf8') as f_out:
                    f_out.write(xml_results)
            except IOError as e:
                print(e)

    Step 5: Call the create_xml() function from main driver (task8_1_starter.py)
            and then test it out.

"""
import os

import ch08_xml.task8_1.support.stats as stats

working_dir = '../../resources/baseball/'
master_filename = 'Master.csv'
salaries_filename = 'Salaries.csv'
results_filename = 'results.txt'
results_xml = 'results.xml'

salfile_fullpath = os.path.join(working_dir, salaries_filename)
mastfile_fullpath = os.path.join(working_dir, master_filename)


input_year = stats.get_year()
top_sals = stats.retrieve_data(salfile_fullpath, mastfile_fullpath, input_year)
stats.print_report(results_filename, top_sals)
