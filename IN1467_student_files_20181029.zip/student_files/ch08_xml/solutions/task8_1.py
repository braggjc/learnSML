"""

      task8_1.py    -   XML

      This final version of the baseball app adds a create_xml()
      method to the stats.py module and outputs data into a file
      in prettified XML format.

"""
import os

import ch08_xml.solutions.support.stats as stats

working_dir = '../../resources/baseball/'
master_filename = 'Master.csv'
salaries_filename = 'Salaries.csv'
results_filename = 'results.txt'
results_xml = 'results.xml'

salfile_fullpath = os.path.join(working_dir, salaries_filename)
mastfile_fullpath = os.path.join(working_dir, master_filename)


input_year = stats.get_year()
top_sals = stats.retrieve_data(salfile_fullpath, mastfile_fullpath, input_year)
stats.print_report(results_filename, top_sals)

stats.create_xml(results_xml, top_sals)
