"""

      task6_1.py   -           Determining the country with the most cities with more than
                               15000 people.  Read cities15000.txt.


"""
from collections import Counter

datafile = '../../resources/cities15000.txt'
cities = []

with open(datafile, encoding='utf8') as cities_file:
    for line in cities_file:
        cities.append(line.strip().split('\t')[8])

most_common = Counter(cities).most_common(5)
print(most_common)
