"""

      task6_2.py   -   Using Generators and Dictionary Comprehensions

      This exercise is a refactoring of the task6_1.py solution.  It
      employs a generator to read data from a file.
"""
from collections import Counter

datafile = '../../resources/cities15000.txt'


def country_generator(filename):
    with open(filename, encoding='utf8') as cities_file:
        for line in cities_file:
            yield line.strip().split('\t')[8]

most_common = Counter(country_generator(datafile)).most_common(5)
print(most_common)
