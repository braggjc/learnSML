import argparse
parser = argparse.ArgumentParser()
parser.add_argument('--step1', help='The first big step in life')
args = parser.parse_args()