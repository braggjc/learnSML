"""

    Run as follows:

    05_argparse2.py -n John Smith -m

"""
import argparse
import pprint


class Person:
    def __init__(self, name, age, is_male):
        self.name = name
        self.age = age
        self.is_male = is_male

    def __str__(self):
        return 'Name: {} Age: {}, Male: {}'.format(self.name, self.age, self.is_male)

def get_args():
    parser = argparse.ArgumentParser(description='Personal characteristics')
    parser.add_argument('-n', '--name', nargs='*', help='The name of the person', default='(no name)')
    parser.add_argument('-a', '--age', help='The age of the person in years', default=0, type=int)
    parser.add_argument('-m', '--is_male', help='Is the person a male', action='store_true')

    return parser.parse_args()

args = get_args()
person = Person(**args.__dict__)
print(person)
pprint.pprint(vars(person), width=1, indent=2)
