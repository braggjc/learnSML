"""
      task7_1_starter.py   -   Using the logging Module

      This file is a continuation of an earlier exercise (task4_2.py).

    This is a modification of task4_2 in which PyYAML was used to
    read server data from server.yaml.

    Note: for imports to work properly, your student_files folder should be on your
    PYTHONPATH.

    Also, remember to run server.py before running this client.

    -------------------------------------------------------------

      Helpful hints:

      1. First, work on logger.py in the starter/support folder on
         configuring/creating the logger.

      2. Second, work on using the log decorator in server.py.

"""
import ch07_adv_functions.starter.client as client


def get_results(school_name):
    results = client.get_schools(school_name)
    print('Found {0} results.  '.format(len(results)))
    if results:
        display_results = input('Display results (def. = y)? ')
        if not display_results or display_results.lower() == 'y':
            for cnt, school in enumerate(results, 1):
                print('{0:<5}{fullname} ({city}, {state})'.format(cnt, **school))


if __name__ == '__main__':
    school_name = input('Enter a full or partial school name (enter to exit): ')
    while school_name:
        get_results(school_name)
        school_name = input('\nEnter a full or partial school name (enter to exit): ')
