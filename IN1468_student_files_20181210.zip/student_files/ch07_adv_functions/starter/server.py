"""
        server.py   - the school search XMLRPC server module

        Helpful hints:
        1. Import the log function from the support/logger.py module.

        2. Add the log decorator to the get_schools() function.

"""
import yaml
from xmlrpc.server import SimpleXMLRPCServer

from ch07_adv_functions.starter.schools import SchoolManager


database = '../../resources/schools.db'

host_data = yaml.load(open('server.yaml').read())
host, port = host_data['host'], host_data['port']


def get_schools(school_name):
    return SchoolManager(database).find(school_name)


server = SimpleXMLRPCServer((host, port), allow_none=True)
print('{host} running on {port}...'.format(host=host, port=port))
server.register_function(get_schools, 'get_schools')
server.serve_forever()
