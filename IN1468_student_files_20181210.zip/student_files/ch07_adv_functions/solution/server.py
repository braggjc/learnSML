"""
        server.py   - the school search XMLRPC server module

"""
import yaml
from xmlrpc.server import SimpleXMLRPCServer

from ch07_adv_functions.solution.schools import SchoolManager
from ch07_adv_functions.solution.support.logger import log

database = '../../resources/schools.db'

host_data = yaml.load(open('server.yaml').read())
host, port = host_data['host'], host_data['port']


@log
def get_schools(school_name):
    return SchoolManager(database).find(school_name)


server = SimpleXMLRPCServer((host, port), allow_none=True)
print('{host} running on {port}...'.format(host=host, port=port))
server.register_function(get_schools, 'get_schools')
server.serve_forever()
