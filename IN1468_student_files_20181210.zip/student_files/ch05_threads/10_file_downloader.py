import os
import queue
import threading
import urllib.request


class FileDownloader(threading.Thread):
    def __init__(self, q):
        threading.Thread.__init__(self)
        self.queue = q

    def run(self):
        url = self.queue.get()
        self.download(url)
        self.queue.task_done()

    def download(self, url):
        req = urllib.request.urlopen(url)
        filename = os.path.basename(url)
        with open(filename, 'wb') as f:
            while True:
                data = req.read(4096)
                if not data:
                    break
                f.write(data)

urls = [
    "http://www.cisco.com/c/en/us/td/docs/ios/12_2/ip/configuration/guide/fipr_c.pdf",
    "http://www.cisco.com/c/en/us/support/docs/ip/access-lists/13608-21.pdf",
    "http://www.cisco.com/c/en/us/td/docs/ios/12_2/configfun/configuration/guide/ffun_c.pdf"
]

q = queue.Queue()

for url in urls:
    q.put(url)

th_count = 3
for th in range(3):
    thread = FileDownloader(q)
    thread.start()

q.join()
