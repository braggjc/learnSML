import sys

value = sys.stdin.read()
print('You sent me {0}'.format(value))
