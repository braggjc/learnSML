"""

	This example requires Python 3.6+.
	It demonstrates the use of f-strings.

"""
first = 'Bob'
last = 'Smith'
age = 37


def format():
    return first + ' ' + last

print(f'{first} {last} {age} {format()}')
