import re

speech = open('../resources/gettysburg.txt').read()
expr = r'four'

match_obj = re.match(expr, speech, re.IGNORECASE)
if match_obj:
    print('Match found for \'{0}\' at position: {1}'.format(expr, match_obj.start()))


match_obj = re.search(r'(\w+) (\w+) (\w+)', speech)
print(match_obj.groups())                # ('Four', 'score', 'and')
print(match_obj.group(0))                # Four score and
print(match_obj.group(1))                # Four
print(match_obj.group(2))                # score
print(match_obj.group(3))                # and

str_matches = re.findall(r'\w+', speech)
print('Total words found: {0}'.format(len(str_matches)))
