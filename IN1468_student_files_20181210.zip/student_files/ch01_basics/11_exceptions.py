import sys
import traceback

try:
    a = input('Number 1: ')
    b = input('Number 2: ')
    result = float(a) / float(b)
    print('Division result is: {0}'.format(result))
except (ValueError, ZeroDivisionError) as err:
    typ, value, tb = sys.exc_info()
    filename, lineno, _, _ = traceback.extract_tb(tb, 1)[0]
    print('Exception type: {typ}'.format(typ=typ))
    print('Exception msg: {msg}'.format(msg=err))
    print('Exception msg: {msg}'.format(msg=value))
    print('TB info: file: {filename}, line: {ln}'.format(filename=filename, ln=lineno))
