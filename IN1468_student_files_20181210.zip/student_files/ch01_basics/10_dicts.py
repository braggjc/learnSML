country = {'name': 'Brazil', 'population': 204000000}

print(country.get('name'))                  # returns Brazil
print(country.get('capital', 'N/A'))        # returns N/A

try:
    capital = country['capital']                  # generates a KeyError
except KeyError:
    capital = '(unknown)'

country['capital'] = 'Brasilia'

for key in country:
    print('{key}: {val} /'.format(key=key, val=country[key]), end=' ')
else:
    print()

for value in country.values():
    print(value, end=' ')
else:
    print()


countries = {
    'Brazil': {'population': 204000000, 'capital': 'Brasilia'},
    'Argentina': {'population': 43100000, 'capital': 'Buenos Aires'},
    'Venezuela': {'population': 30600000, 'capital': 'Caracas'}
}

countries_sorted = [(country_name, country.get('capital', 'N/A')) for country_name, country in sorted(countries.items())]
print(countries_sorted)




#--------------------------------------------------------------
# using an OrderedDict
from collections import OrderedDict

d4 = OrderedDict([('Smith', 43), ('James', 32), ('Edwards', 36), ('Cramer', 29)])
for val in d4.values():
    print(val, end=' ')
else:
    print()

d4.move_to_end('Smith')
for val in d4.values():
    print(val, end=' ')
else:
    print()


#--------------------------------------------------------------
# using a defaultdict
from collections import defaultdict
dict1 = defaultdict(str)
dict1['greet1'] = 'hello'
print(dict1['greet1'], dict1['greet2'])
