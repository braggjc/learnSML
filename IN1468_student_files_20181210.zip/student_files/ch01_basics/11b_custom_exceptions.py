import sys
import traceback


class SameInputException(Exception):
    """Exception occurs when inputs are the same"""
    def __init__(self, same_val):
        self.same_val = same_val
        self.args = ('Inputs, {0}, cannot be the same.'.format(self.same_val),)

    def __str__(self):
        return self.args[0]


try:
    a = input('Number 1: ')
    b = input('Number 2: ')
    if a == b:
        raise SameInputException(a)
    result = float(a) / float(b)
    print('Division result is: {0}'.format(result))
except (SameInputException, ValueError, ZeroDivisionError) as err:
    typ, value, tb = sys.exc_info()
    filename, lineno, _, _ = traceback.extract_tb(tb, 1)[0]
    print('Exception type: {typ}'.format(typ=typ))
    print('Exception msg: {msg}'.format(msg=err))
    print('Exception msg: {msg}'.format(msg=value))
    print('TB info: file: {filename}, line: {ln}'.format(filename=filename, ln=lineno))
