"""

    27_prettytable.py   -    To run this example you MUST [sudo] pip install prettytable.
                             Reads from variable-record length contacts.dat file in the resources folder.


"""
from collections import namedtuple

import prettytable

columns = ['Name', 'Address', 'Phones', 'Email']
Contact = namedtuple('Contact', columns)
pt = prettytable.PrettyTable(columns)
pt.align = 'l'                      # left align

with open('../resources/contacts.dat', encoding='utf-8') as f:
    for line in f:
        data = line.strip().split(',')
        name, addr, *phones, birthdate, email, company, position = data         # only works in Py3
        phone = ' '.join([ph + ' ' + typ + '\n' for ph, typ in zip(phones[::2], phones[1::2])])
        pt.add_row(Contact(name, addr, phone, email))

print(pt)
