weekdays = [
    'Monday','Tuesday',
    'Wednesday','Thursday','Friday'
]

with open('../resources/access_.log') as f:
    for idx, line in enumerate(f):
        if idx == 21:
            print(line)


sa_country_data = [
    ('Brazil', 'Columbia', 'Argentina', 'Peru', 'Venezuela',
     'Chile', 'Equador', 'Bolivia', 'Paraguay', 'Uruguay',
     'Guyana', 'Suriname', 'French Guiana', 'Falkland Islands'),
     (204000000, 48500000, 43100000, 31100000, 30600000,
      18000000, 16300000, 10500000, 7000000, 3300000,
      747000, 560000, 262000, 3000)
]

for value in reversed(sa_country_data[0]):
    print(value)

for country, pop in zip(*sa_country_data):
    print('{0:<20}{1:>15}'.format(country, pop))
