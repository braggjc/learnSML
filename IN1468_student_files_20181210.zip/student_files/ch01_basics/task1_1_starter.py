"""

      task1_1_starter.py   -   Python Basics Overview

      Reads data from resources/cities15000.txt (a tsv file).
      Determines the largest city and highest city.
      Allows for searching by city names to determine a city population.


      Helpful hints:
      1. Examine the file cities15000.txt.  We will use a sequence to hold City namedtuples
         Create the City namedtuple definition such that it contains a name, population, elevation, and country

      2. Read from the data file into this data structure.  Be sure to use proper error handling
         as discussed in the materials.  The columns you should read are as follows: 1=name, 8=country (2-ltr code),
         14=population, 16=elevation (digital elevation model).  Column 0 is the geonameid.

         NOTE: you will need to split on a TAB ('\t') since this file is a tab-separated value file.

         Once complete, you should have a list of City namedtuples.

      3. To find the largest city, sort the cities data structure by population.  The first element in the
         list should be the largest city (a City namedtuple).

          Tip: As an example of sorting, the following would sort by country:
                key=lambda city: city.country

      4. Repeat step 3, this time sorting by elevation instead of population.

      5. To create a the search functionality, ask for user input to input a city name.  You can use
         the string method: capitalize() to capitalize the city name.

      6. Iterate over the list of City namedtuples checking the user input string against the name attribute of the
         namedtuple.  If it is a match, print or save the City namedtuple.

      7. Display the results.

"""
from collections import namedtuple
import os

working_dir = '../resources'
city_data = 'cities15000.txt'
cities = []
