"""

      task1_1.py   -   Python Basics Overview

      Reads data from resources/cities15000.txt (a tsv file).
      Determines the largest city and highest city.
      Allows for searching by city names to determine a city population.

"""
from collections import namedtuple
import os


working_dir = '../../resources'
city_data = 'cities15000.txt'
cities = {}

City = namedtuple('City', 'population elevation country')

try:
    with open(os.path.join(working_dir, city_data), encoding='utf8') as cities_file:
        for line in cities_file:
            city_record = line.strip().split('\t')
            name = city_record[1]
            country_code = city_record[8]
            population = int(city_record[14])
            elevation = int(city_record[16])

            cities[name] = City(population, elevation, country_code)       # key = city name, value = [populuation, elevation]

except IOError as e:
    print('Error: {0}'.format(e))

by_size = sorted(cities, key=lambda k: cities.get(k, 0).population, reverse=True)
by_elevation = sorted(cities, key=lambda k: cities.get(k, 0).elevation, reverse=True)

name, city = by_size[0], cities.get(by_size[0])
print('Largest city: {0} with: {1:,} people.'.format(name, city.population))

name, city = by_elevation[0], cities.get(by_elevation[0])
print('Highest city: {0} at: {1} meters ({2} feet)'.format(name, city.elevation, city.elevation * 3.28))

search = input('City name to find details on: ')
search_capitalized = ' '.join([word.capitalize() for word in search.split()])
city = cities.get(search_capitalized, City(0, 0, ''))
print('City: {0}, pop: {1:,}, elev: {2} meters.'.format(search_capitalized, city.population, city.elevation))
