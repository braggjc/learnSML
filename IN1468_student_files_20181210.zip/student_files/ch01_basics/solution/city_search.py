"""

      city_search.py   -   Refactored task1_1.py solution, used with task1_2 module (exercise)

      Reads data from resources/cities15000.txt (a tsv file).
      Determines the largest city and highest city.
      Allows for searching by city names to determine a city population.

"""
from collections import namedtuple

_cities = []
City = namedtuple('City', 'name population elevation country')


def read_data(filename):
    try:
        with open(filename, encoding='utf8') as f:
            for line in f:
                city_data = line.strip().split('\t')
                name = city_data[1]
                country_code = city_data[8]
                population = int(city_data[14])
                try:
                    elevation = int(city_data[16])
                except ValueError:
                    elevation = 0
                _cities.append(City(name, population, elevation, country_code))
    except IOError as err:
        print(err.args[0])


def largest_city():
    return sorted(_cities, key=lambda city: city.population, reverse=True)[0]


def highest_city():
    return sorted(_cities, key=lambda city: city.elevation, reverse=True)[0]


def search(search_str):
    capitalized_search_str = ' '.join([word.capitalize() for word in search_str.split()])
    return [city for city in _cities if capitalized_search_str in city.name]
