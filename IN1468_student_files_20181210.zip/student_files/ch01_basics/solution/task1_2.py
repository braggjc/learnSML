"""

      task1_2.py   -   Python Basics Overview

      Reads data from resources/cities15000.txt (a tsv file).
      Determines the largest city and highest city.
      Allows for searching by city names to determine a city population.

"""
import os

import prettytable                                      # to use prettytable, you must [sudo] pip install prettytable first

import ch01_basics.solution.city_search as cs

working_dir = '../../resources'
city_data = 'cities15000.txt'

cs.read_data(os.path.join(working_dir, city_data))

largest = cs.largest_city()
highest = cs.highest_city()

print('Largest city: {0}, {1} with: {2:,} people'.format(largest.name, largest.country, largest.population))
print('Highest city: {0}, {1} at: {2} meters ({3} feet)'.format(highest.name, highest.country,
                                                                highest.elevation, highest.elevation * 3.28))
city_search = input('City to search for: ')

results = cs.search(city_search)
if not results:
    print('No cities found.')
else:
    pt = prettytable.PrettyTable(['Name', 'Population', 'Elevation', 'Country'])
    pt.align = 'l'   # left align
    for city in results:
        pt.add_row(city)
    print(pt)
