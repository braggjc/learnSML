from collections import namedtuple
import os

working_dir = '../../resources'
city_data = 'cities15000.txt'
cities = []

City = namedtuple('City', 'name population elevation country')

with open(os.path.join(working_dir, city_data), encoding='utf8') as f:
    for line in f:
        city_data = line.strip().split('\t')
        name = city_data[1]
        country_code = city_data[8]
        population = int(city_data[14])
        elevation = int(city_data[16])
        cities.append(City(name, population, elevation, country_code))

largest = sorted(cities, key=lambda city: city.population, reverse=True)[0]
highest = sorted(cities, key=lambda city: city.elevation, reverse=True)[0]

print('Largest city: {0}, {1} with: {2:,} people'.format(largest.name, largest.country, largest.population))
print('Highest city: {0}, {1} at: {2} meters ({3} feet)'.format(highest.name, highest.country,
                                                                highest.elevation, highest.elevation * 3.28))

city_search = input('City to search for: ')
city_search_capitalized = ' '.join([word.capitalize() for word in city_search.split()])
print('Searching for: {0}'.format(city_search_capitalized))
results = [city for city in cities if city_search_capitalized in city.name]
if not results:
    print('No cities found.')
else:
    print('{0:<40}{1:>15}{2:>15}{3:>8}'.format('Name', 'Population', 'Elevation', 'Country'))
    for city in results:
        print('{0:<40}{1:>15,}{2:>15,}{3:>8}'.format(*city))
