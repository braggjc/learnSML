sa_countries = [
    ('Brazil', 204000000), ('Columbia', 48500000),
    ('Argentina', 43100000), ('Peru', 31100000),
    ('Venezuela', 30600000), ('Chile', 18000000),
    ('Equador', 16300000), ('Bolivia', 10500000),
    ('Paraguay', 7000000), ('Uruguay', 3300000),
    ('Guyana', 747000), ('Suriname', 560000),
    ('French Guiana', 262000),
]

print(sa_countries[2])
print(sa_countries[-2:])
print('brazil'.capitalize() in list(zip(*sa_countries))[0])

# alternate way using list_comprehension:
print(bool([country for country, _ in sa_countries if 'brazil'.capitalize() == country]))

sa_countries.append(('Falkland Islands', 3000))
sa_countries.insert(1, ('Falkland Islands', 3000))
print(sa_countries)

print(max(sa_countries, key=lambda country: country[1]))

for country, pop in sa_countries:
    print(country)
