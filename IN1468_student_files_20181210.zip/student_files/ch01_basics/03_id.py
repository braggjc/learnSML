item1 = 'hi there!'
item2 = item1
item3 = str('hi there!')
print(id(item1), id(item2), id(item3))

list1 = [1, 2, 3]
list2 = list1
list3 = list1[:]	    # makes a copy

print(id(list1))
print(id(list2))
print(id(list3))
