import datetime


now1 = datetime.datetime.now()      # current date & time
now2 = datetime.date.today()        # current date
print(now1, now2)

d1 = datetime.date(2009, 3, 27)
print(d1.year, d1.month, d1.day)
print('formatted using strftime: {fmt}'.format(fmt=d1.strftime('Day %d of %B, Day %j in %Y, ')))

d2 = datetime.date(2011, 6, 17)
print(d2 - d1)

date_str = 'February 17, 1985'
d3 = datetime.datetime.strptime(date_str, '%B %d, %Y')
print(d3.month)
