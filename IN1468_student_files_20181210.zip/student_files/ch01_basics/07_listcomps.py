import ipaddress

ips1 = ipaddress.ip_network('192.168.0.0/29')
ips2 = ipaddress.ip_network('192.168.0.0/30')

remaining = [ip for ip in ips1 if ip not in ips2]
print(remaining)
