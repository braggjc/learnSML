my_str = str('Python is great!')            # using the str() class constructor


#---------------------------------------
#   Several encoding / decoding examples
#
print('\u26C8')                             # using 16-bit unicode chars, note: to convert to utf-8, use: '\u26C8'.encode('utf-8')
print('\N{UMBRELLA}')                       # using named unicode


b1 = bytes([65, 66, 67])	                # holds 3 ascii byte values
print(b1, b1.decode(), type(b1))            # b'ABC'  ABC  <class 'bytes'>

b2 = b'DEF'
print(b2, b2.decode(), type(b2))            # b'DEF'  DEF  <class 'bytes'>

b3 = bytes('This is utf-8 encoded', 'utf-8')
print(b3, b3.decode(), type(b3))

b4 = bytes('This is utf-16 encoded', 'utf-16')
# print(b4.decode())                       # error, utf-8 decoder would be used
print(b4.decode('utf-16'))

print('This will be utf-16 encoded'.encode('utf-16').decode('utf-16'))


try:
    result1 = b'\x88foo'.decode('utf-8', 'strict')
    print(result1)
except UnicodeDecodeError as err:
    print(err)

result2 = b'\x88foo'.decode('utf-8', 'ignore')
result3 = b'\x88foo'.decode('utf-8', 'replace')
print(result2, result3)



#---------------------------------------
#   Formatting examples
#
print('The following are examples of using the format() method:')
employee = ['Bill', 'Smith', 37]
fmt_results = '{0} {1} {2}'.format(*employee)
print(fmt_results)

employee = ['Bill', 'Smith', 37]
fmt_results = '{0:-^20} {1:-<30} {2:>8}'.format(*employee)
print(fmt_results)

employee = {'first': 'Bill', 'last': 'Smith', 'age': 37}
fmt_results = '{fst: ^20} {lst: <30} {age:>8}'.format(fst=employee['first'], lst=employee['last'], **employee)
print(fmt_results)

employee = {'first': 'Bill', 'last': 'Smith', 'age': 37}
fmt_results = '{first: ^20} {last: <30} {age:>8}'.format(**employee)
print(fmt_results)

employee = {'first': 'Bill', 'last': 'Smith', 'age': 37}
col_widths = [20, 30, 8]
fmt_results = '{first: ^{0}} {last: <{1}} {age:>{2}}'.format(*col_widths, **employee)
print(fmt_results)
