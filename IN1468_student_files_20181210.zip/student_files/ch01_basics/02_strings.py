import linecache

# shorter files approach for reading a specific line
print('Example reading a specific line (smaller files): ')
line22 = linecache.getline('../resources/access_.log', 22).strip()

print(line22)                       # 199.236.222.174 - - [04/Sep/1995:00:00:31 -0400] "GET /graphics/BUTTON1.GIF HTTP/1.0" 200 1434
print(line22[0])                    # 1
print(line22[0:15])                 # 199.236.222.174
print(line22[:3])                   # 199
print(line22[-4:])                  # 1434

print(line22.find('GET'))           # 50
print(line22.find('POST'))          # -1
print(line22[0:15].split('.'))      # ['199', '236', '222', '174']
print("GET /graphics/BUTTON1.GIF HTTP/1.0".lower())     # get /graphics/button1.gif http/1.0

# larger files
print('Example reading a specific line (larger files): ')
with open('../resources/access_.log') as f:
    for idx, line in enumerate(f):
        if idx == 21:
            print(line)
