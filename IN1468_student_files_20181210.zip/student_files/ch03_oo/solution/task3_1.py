"""
    task3_1.py  -   school listing test file

    This file serves as a driver to test the SchoolManager class found
    within schools.py.
    Note: for imports to work properly, your student_files folder should be on your
    PYTHONPATH.
"""
import sqlite3
import sys

from ch03_oo.solution.schools import SchoolManager

database = '../../resources/schools.db'


def main():
    sch_mgr = SchoolManager(database)
    school_name = input('Enter a full or partial school name: ')
    try:
        results = sch_mgr.find(school_name)
    except sqlite3.Error:
        sys.exit()

    print('Found {0} results.  '.format(len(results)), end=' ')
    display_results = input('Display results (def. = y)? ')
    if not display_results or display_results.lower() == 'y':
        for cnt, school in enumerate(results, 1):
            print('{0:<5}{1}'.format(cnt, school))


if __name__ == '__main__':
    main()
