"""
    schools.py  -   Module for the School and SchoolManger classes

    Class module for our School and SchoolManager classes.
    This file is initially imported by task3_1.py and executed there.

    The School class simply holds information about school data.
    The SchoolManager is used to connect to and query against
    the schools.db sqlite3 database.

    -------------------------------------------------------------------------

    Helpful Hints:
    1. Create the School class with the following attributes:
        school_id, fullname, city, state, country

    2. In the __init__, pass in parameters for each and set them as instance attributes


    -------


    3. Create the SchoolManager class beneath School with the following methods:
        __init__, __del__, find

        Remember each method should have a self passed in.

        For now, just put a 'pass' statement in the body of each method.


    4. Complete the __init__(), passing appropriate school data


    5. In the constructor, create a connection and cursor as follows:
        self.connection = sqlite3.connect(db_filename)
        self.connection.row_factory = Row
        self.cursor = self.connection.cursor()

        Don't forget to import sqlite3

        The constructor is finished.


    6. Implement the find() method.
       Create a list that will return (School object instances).
       Using the SchoolManager's cursor object (self.cursor), invoke the execute() method.

       You may use the following sql:

            SELECT_SCHOOLS_SQL = 'SELECT school_id, fullname, city, state, country FROM schools WHERE fullname like ?'

	 Note: when invoking cursor.execute(), that params argument should protect
            against injection attacks by adding % manually to each end of the
            parameter, as follows:   ('%' + school_name + '%',)

       Iterate over the cursor retrieving all found records.  Add to the returned objects
       in the form of School instances to the return list.

       Don't forget to return the list of School objects.


    8. Implement the destructor function:  __del__().  This function will have one line
       to close the connection object.  Can you do this on your own?
       Note: __del__() will be automatically called when the SchoolManager object goes out of scope.

    9. Finish by proceding to task3_1_starter.py and completing the steps within that source file.
"""

