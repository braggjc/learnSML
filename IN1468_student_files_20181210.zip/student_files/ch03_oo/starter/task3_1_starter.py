"""
    task3_1_starter.py  -   school listing driver

    This file serves as a driver to test the SchoolManager class found
    within schools.py.
    Note: for imports to work properly, your student_files folder should be on your
    PYTHONPATH.

    Helpful hints:
    1. Open schools.py, complete the two required classes as described
    2. Remove the pass from the main() method below.
    3. Follow the hints to access and use the SchoolManager

"""
from ch03_oo.starter.schools import SchoolManager

database = '../../resources/schools.db'


def main():
    pass
    # remove the pass statement above
    # instantiate your SchoolManager
    # prompt the user for a partial school name to search for
    # query for and display the results
    # be sure to properly handle error conditions (no db found, improper input, etc.)


if __name__ == '__main__':
    main()
