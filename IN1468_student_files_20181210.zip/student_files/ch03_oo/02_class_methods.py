import linecache


class City:
    """ Encapsulates information about a city containing a population over 15,000"""
    def __init__(self, name, country='', population=0, elevation=-1):
        self.name = name
        self.country = country
        self.population = population
        self.elevation = elevation
        self.latitude = None
        self.longitude = None

    def location(self, loc):
        """
            Establishes a city's coordinates
            :param loc: should be provided as a tuple containing latitude and longitude values
            :return: None
        """
        lat, lng = loc
        self.latitude = lat
        self.longitude = lng

    def __str__(self):
        return '{0}'.format(self.name)


city_data = linecache.getline('../resources/cities15000.txt', 21780).strip().split('\t')
c = City(city_data[1], city_data[8], city_data[14], city_data[15])
c.nickname = 'The Big Apple'

c.location((city_data[4], city_data[5]))
print(c, c.latitude, c.longitude)
