"""
      task2_1.py   -   Python Database API 2.0

      Reads data from school.db by providing a get_location() function and a partial or full
      name of a school.

      Data returned from the search of the database returns name, city, and state for all
      matching results.

      Uses a named tuple to store school data.

"""
import sqlite3
from collections import namedtuple

School = namedtuple('School', 'name city state')

data_sourcefile = 'schools.db'
SELECT_SCHOOLS_SQL = 'SELECT fullname, city, state FROM schools WHERE fullname like ?'


def get_location(school_name):
    school_data = []
    connection = None

    try:
        connection = sqlite3.connect(data_sourcefile)
    except sqlite3.Error as err:
        print('Error connecting to database: {0}'.format(err))
        return school_data

    cursor = connection.cursor()

    try:
        cursor.execute(SELECT_SCHOOLS_SQL, ('%' + school_name + '%',))
        for sch in cursor:
            school_data.append(School(*sch))
    except sqlite3.Error as e:
        print('Error processing request: {0}'.format(e))
        return school_data
    finally:
        if connection:
            connection.close()
    return school_data


name = input('School name (or partial name): ')
results = get_location(name)
print('Matches for {0}:'.format(name))
for school in results:
    print('{0}, {1} {2}'.format(*school))
    # any of these formatted outputs will work as well:
    # print('{name}, {city} {state}'.format(**school._asdict()))
    # print('{0}, {1} {2}'.format(school[0], school[1], school[2]))
    # print('{0}, {1} {2}'.format(school.name, school.city, school.state))
    # print('{name}, {city} {state}'.format(name=school.name, city=school.city, state=school.state))
