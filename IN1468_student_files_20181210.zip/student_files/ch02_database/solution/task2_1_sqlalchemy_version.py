"""
        task2_1 (completed using SQLAlchemy)
"""
from sqlalchemy import create_engine, MetaData, Table
from sqlalchemy.orm import mapper, sessionmaker
from sqlalchemy.exc import SQLAlchemyError
import sys


class School(object):
    pass


def init_db(url):
    try:
        db = create_engine(url, echo=False)
        metadata = MetaData(db)
        SchoolTable = Table('schools', metadata, autoload=True)
        mapper(School, SchoolTable)
    except SQLAlchemyError as err:
        print('Error connecting to database: {0}'.format(err))
        sys.exit()


def get_location(school_name):
    session = None
    query_results = []
    try:
        Session = sessionmaker(autoflush=True, autocommit=True)
        session = Session()
        query_results = session.query(School).filter(School.fullname.like('%'+school_name+'%')).all()
    except AttributeError as err:
        print('Error with Table data:\n{0}'.format(err))
    except SQLAlchemyError as err:
        print('Error working with db: {0}'.format(err))
    finally:
        session.close()

    return query_results


init_db('sqlite:///schools.db')
results = get_location('Loyola')

for school in results:
    print('{0:<40}{1:<20}{2:<4}'.format(school.fullname, school.city, school.state))
