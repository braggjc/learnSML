"""

    02_fetching_rows.py

    The following source will create a namedtuple called School.

    It then retrieves rows of data from schools.db which has assumed to have been
    created already.  If it has not, run the 01_create_schools_db example in this folder first.

"""
from collections import namedtuple
from contextlib import closing
import sqlite3

School = namedtuple('School', 'name city state')
schools3 = []
state = 'CO'
try:
    with closing(sqlite3.connect('schools.db')) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT fullname, city, state FROM schools WHERE state=?', (state,))

        school1 = School(*cursor.fetchone())

        schools2 = [School(*sch) for sch in cursor.fetchmany(size=3)]

        for sch in cursor:
            schools3.append(School(sch[0], sch[1], sch[2]))
except sqlite3.Error as e:
    print('Error: {0}'.format(e))

print('Schools in {0}'.format(state))
for school in schools3:
    print('{name}, {city} {state}'.format(name=school.name,
                                          city=school.city, state=school.state))
