"""

    02_fetching_rows.py

    The following source will create a namedtuple called School.

    It then retrieves rows of data from schools.db which has assumed to have been
    created already.  If it has not, run the 01 example in this folder first.

"""
from collections import namedtuple
from contextlib import closing
import sqlite3

School = namedtuple('School', 'name city state')
schools3 = []
state = 'CO'
try:
    with closing(sqlite3.connect('schools.db')) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT fullname, city, state FROM schools WHERE state=?', (state,))

        school1 = School(*cursor.fetchone())

        schools2 = [School(*sch) for sch in cursor.fetchmany(size=3)]

        for sch in cursor:
            schools3.append(School(sch['fullname'], sch['city'], sch['state']))
except sqlite3.Error as e:
    print('Error: {0}'.format(e))

print('Schools in {0}'.format(state))
for school in schools3:
    print('{name}, {city} {state}'.format(name=school.name,
                                          city=school.city, state=school.state))
