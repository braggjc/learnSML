from xmlrpc.client import ServerProxy

from ch04_network_prog.solution.globals import host, port


def get_schools(school_name):
    results = []
    proxy = ServerProxy('http://{host}:{port}'.format(host=host, port=port), allow_none=True)
    try:
        results = proxy.get_schools(school_name)
    except Exception as err:
        print('Error during XMLRPC request: {0}'.format(err))
    return results


if __name__ == '__main__':
    print('Run server.py first, then run task4_1_starter.py next')
