"""
    globals.py  -   used for data related to both the client AND server environements
"""

host = 'localhost'
port = 8059
