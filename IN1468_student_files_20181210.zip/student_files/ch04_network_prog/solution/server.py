from xmlrpc.server import SimpleXMLRPCServer

from ch04_network_prog.solution.globals import host, port
from ch04_network_prog.solution.schools import SchoolManager

database = '../../resources/schools.db'


def get_schools(school_name):
    return SchoolManager(database).find(school_name)


server = SimpleXMLRPCServer((host, port), allow_none=True)
print('{host} running on {port}...'.format(host=host, port=port))
server.register_function(get_schools, 'get_schools')
server.serve_forever()
