"""
    task4_1.py  -   school listing test file

    This file is a continuation of the previous exercise (task3_1.py).

    In this part of the exercise, the driver will communicate with a new module.  This
    module contains an XMLRPC client.  The XMLRPC client remotely communicates
    with the XMLRPC server.

    Note: for imports to work properly, your student_files folder should be on your
    PYTHONPATH.

    Also, remember to run server.py before running this client.
"""
import ch04_network_prog.solution.client as client


if __name__ == '__main__':
    school_name = input('Enter partial school name: ')
    results = client.get_schools(school_name)
    for cnt, school in enumerate(results, 1):
        print('{0:<5}{fullname} ({city}, {state})'.format(cnt, **school))
