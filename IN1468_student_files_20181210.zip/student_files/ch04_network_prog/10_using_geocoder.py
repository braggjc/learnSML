import geocoder


def get_results(address):
    results = geocoder.arcgis(address).json
    return results


def get_coordinates(address):
    results = geocoder.arcgis(address).json
    return results.get('lat'), results.get('lng')


def get_address(address):
    results = geocoder.arcgis(address).json
    return results.get('address')


address = 'Walt Disney World, Lake Buena Vista, FL'


coordinates = get_coordinates(address)
print('Coordinates: {0}'.format(coordinates))
addr = get_address(address)
print('Resolved Address: {0}'.format(addr))
raw = get_results(address)
print('Raw data: {0}'.format(raw))
