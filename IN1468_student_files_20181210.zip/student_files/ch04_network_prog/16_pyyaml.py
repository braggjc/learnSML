import yaml

results = yaml.load(open('person.yaml').read())

print(results)

yaml.dump(results, open('person_dump.yaml', 'w'), default_flow_style=False)

