"""
    schools.py  -   Module for the School and SchoolManger classes

    You may opt to use your schools.py from task3_1 instead.  If so,
    simply replace this file with the one you created earlier.

    The School class simply holds information about school data.
    The SchoolManager is used to connect to and query (and eventually insert and delete records to/from)
    the schools.db sqlite3 database.
"""
import sqlite3


class School:
    def __init__(self, school_id, fullname, city, state, country):
        self.school_id = school_id
        self.fullname = fullname
        self.city = city
        self.state = state
        self.country = country

    def __str__(self):
        return '{fullname} ({city}, {state})'.format(fullname=self.fullname, city=self.city, state=self.state)

    __repr__ = __str__


class SchoolManager:
    def __init__(self, db_file):
        self.tbl = 'schools'
        try:
            self.connection = sqlite3.connect(db_file)
            self.cursor = self.connection.cursor()
        except sqlite3.Error as err:
            raise sqlite3.Error('Error connecting to database: {0}'.format(err))

    def __del__(self):                                              # when SchoolManager goes out of scope, the connection will close
        self.connection.close()

    def find(self, school_name):
        school_data = []
        SELECT_SCHOOLS_SQL = 'SELECT school_id, fullname, city, state, country FROM schools WHERE fullname like ?'

        try:
            self.cursor.execute(SELECT_SCHOOLS_SQL, ('%' + school_name + '%',))
            for sch in self.cursor:
                school_data.append(School(*sch))
        except sqlite3.Error as err:
            raise sqlite3.Error('Error finding "{0}": {1}'.format(school_name, err))

        return school_data
