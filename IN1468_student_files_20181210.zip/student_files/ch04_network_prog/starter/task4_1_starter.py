"""
    task4_1_starter.py  -   document listing test file

    This file is used to invoke the XMLRPC client (client.py) which communicates with server.py.

    In this part of the exercise, the driver will communicate with a new module.

    Note: for imports to work properly, your student_files folder should be on your
    PYTHONPATH.
"""
import ch04_network_prog.starter.client as client



