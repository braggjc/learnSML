"""
    fire_plot.py    -   Plots (using google maps) current (live) wild fires.
"""
from gmplot import GoogleMapPlotter
import requests


feed = 'https://inciweb.nwcg.gov/feeds/json/markers/'
data = requests.get(feed).json()

# create list of tuples containing [(lat, lng), (lat, lng), ...] values
fire_coords = [(float(fire_dict.get('lat', '0')), float(fire_dict.get('lng', '0')))
               for fire_dict in data.get('markers', [])]

g_map = GoogleMapPlotter(37, 95, zoom=3)
g_map.heatmap(*zip(*fire_coords), radius=20)
g_map.draw('fires.html')


