import http.client
import json
from urllib.parse import quote_plus

url = '/arcgis/rest/services/World/GeocodeServer/find?f=json&text={0}&maxLocations=1'
address = 'Walt Disney World, Lake Buena Vista, FL'

path = url.format(quote_plus(address))
connection = http.client.HTTPSConnection('geocode.arcgis.com')
connection.request('GET', path)

raw_json_response = connection.getresponse().read()
json_response = raw_json_response.decode()

geo_object = json.loads(json_response)

geo_object = geo_object.get('locations', [{}])[0]
print(geo_object.get('name', 'addr not found'))
print(geo_object.get('feature', {}).get('geometry', {}).get('x'),
      geo_object.get('feature', {}).get('geometry', {}).get('y'))



