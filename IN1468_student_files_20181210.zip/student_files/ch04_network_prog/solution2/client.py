import yaml
from xmlrpc.client import ServerProxy


def _load_server_data():
    host_data = yaml.load(open('server.yaml').read())
    host, port = host_data['host'], host_data['port']
    return host, port


def get_schools(school_name):
    host, port = _load_server_data()
    results = []
    proxy = ServerProxy('http://{host}:{port}'.format(host=host, port=port), allow_none=True)
    try:
        results = proxy.get_schools(school_name)
    except Exception as err:
        print('Error during XMLRPC request: {0}'.format(err))
    return results


if __name__ == '__main__':
    print('Run server.py first, then run task4_1_starter.py next')
