import json
import requests
import yaml


def _load_server_data(datafile):
    host_data = yaml.load(open(datafile).read())
    host, port = host_data.get('host'), host_data.get('port')
    return host, port


def get_schools(school_name):
    host, port = _load_server_data('server.yaml')
    results = []
    endpoint = 'http://{host}:{port}/jsonrpc'.format(host=host, port=port)
    headers = {'content-type': 'application/json'}

    payload = {
        'method': 'get_schools',
        'params': [school_name],
        'jsonrpc': 2.0,
        'id': 0
    }

    response = requests.post(endpoint, data=json.dumps(payload), headers=headers).json()
    return response.get('result') or response.get('error')

print(get_schools('Loyola'))
