"""

    To make this work:   pip install json-rpc

"""
from jsonrpc import JSONRPCResponseManager, dispatcher
from werkzeug.wrappers import Request, Response
from werkzeug.serving import run_simple
import yaml

import ch04_network_prog.solution3_json_rpc.schools as schools

database = '../../resources/schools.db'


def _load_server_data(datafile):
    host_data = yaml.load(open(datafile).read())
    host, port = host_data.get('host'), host_data.get('port')
    return host, port


@dispatcher.add_method
def get_schools(school_name):
    records = schools.SchoolManager(database).find(school_name)
    return ['{} ({}, {})'.format(record.fullname, record.city, record.state) for record in records]


@Request.application
def application(request):
    print(request.data)
    response = JSONRPCResponseManager.handle(request.data, dispatcher)
    return Response(response.json, mimetype='application/json')

host, port = _load_server_data('server.yaml')
run_simple(host, port, application)
