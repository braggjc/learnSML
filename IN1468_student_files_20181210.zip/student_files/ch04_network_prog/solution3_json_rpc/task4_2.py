import ch04_network_prog.solution3_json_rpc.client as client


def get_results(school_name):
    return client.get_schools(school_name)


if __name__ == '__main__':
    school_name = input('Enter a full or partial school name (enter to exit): ')
    while school_name:
        results = get_results(school_name)
        print('Found {0} results.  '.format(len(results)))
        if results:
            for cnt, school in enumerate(results, 1):
                print(school)

        school_name = input('\nEnter a full or partial school name (enter to exit): ')
