"""

            test_schools.py - a unit test module for the schools.py
                              SchoolManager and School classes



    Instructions:
    -------------

    2. Within this file, create a testcase to test your SchoolManager
       in the starter/schools.py file.  It has already been imported for you.

       Also, a unit test has been started for you.
       Complete the class by making a test_______() method
       which checks if a proper list of School objects was returned.

        Hints:

            a) Complete the setUp() method so that it instantiates a SchoolManager() object
               (pass in the provided db_file location).
               Attach the SchoolManager instance to the self reference
               so that it becomes available to the test________()
               method.

            b) In the test______() method, a possible search term
               could be 'citadel' which
               should return the following:

                    [School('citadel', 'The Citadel', 'Charleston', 'SC', 'USA')]

               Use this example to ensure the find() method works as expected.


    3. Run the unit test to verify the find() method works as expected.
       You may run this file directly or within PyCharm as a unit test

"""
import unittest
from ch09_testing.starter.schools import SchoolManager, School


class TestSchoolManager(unittest.TestCase):

    def setUp(self):
        db_file = '../../../resources/schools.db'
        # 1. instantiate a SchoolManager(), set a self reference to it




def main():
    unittest.main()

if __name__ == '__main__':
    main()
