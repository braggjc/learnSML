import unittest
from ch09_testing.solution.schools import SchoolManager, School


class TestSchoolManager(unittest.TestCase):

    def setUp(self):
        db_file = '../../../resources/schools.db'
        self.schoolMgr = SchoolManager(db_file)


    def test_find_query(self):
        search_term = 'citadel'
        sch = School('citadel', 'The Citadel', 'Charleston', 'SC', 'USA')
        expected = [sch]
        actual = self.schoolMgr.find(search_term)
        self.assertIsInstance(actual[0], School)
        self.assertEqual(expected[0].school_id, actual[0].school_id)
        self.assertEqual(expected[0].fullname, actual[0].fullname)
        self.assertEqual(expected[0].city, actual[0].city)
        self.assertEqual(expected[0].state, actual[0].state)
        self.assertEqual(expected[0].country, actual[0].country)

    def test_find_bad_input(self):
        actual = self.schoolMgr.find('xyz')
        self.assertIsInstance(actual, list)
        self.assertListEqual(actual, [])


def main():
    unittest.main()

if __name__ == '__main__':
    main()
